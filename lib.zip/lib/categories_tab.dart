import 'package:badges/badges.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'commons/utils.dart';
class Categories extends StatefulWidget {
  const Categories({Key key}) : super(key: key);

  @override
  _CategoriesState createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  bool _isLoading = false;
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('categories').orderBy('catTimeStamp',descending: true).snapshots(),
        builder: (context,snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data.docs.length,
              itemBuilder: (context, index) {
                DocumentSnapshot user = snapshot.data.docs[index];

                return Card(
                  color: Colors.white,
                  elevation: 2,

                  margin: EdgeInsets.all(4),
                  child: GestureDetector(
                    onTap: () {

                    },
                    child: Column(
                      children: [
                        GestureDetector(
                          onTap: () =>{},
                          child: Row(
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.fromLTRB(6.0,2.0,10.0,2.0),
                                child: Container(
                                    width: 48,
                                    height: 48,
                                    child: Image.asset('images/logo.png')
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(user.get("userName"),style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),
                                  Padding(
                                    padding: const EdgeInsets.all(2.0),
                                    child: Text(Utils.readTimestamp(user.get('catTimeStamp')),style: TextStyle(fontSize: 16,color: Colors.black87),),
                                  ),
                                ],
                              ),
                              Spacer(),
                              PopupMenuButton<int>(
                                itemBuilder: (context) => [
                                  PopupMenuItem(
                                    value: 1,
                                    child: Row(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(right:8.0,left:8.0),
                                          child: Icon(Icons.report),
                                        ),
                                        Text("Report"),
                                      ],
                                    ),
                                  ),
                                ],
                                initialValue: 1,
                                onCanceled: () {
                                  print("You have canceled the menu.");
                                },
                                onSelected: (value) {

                                },
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 70,
                          child: Row(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Column(
                                    mainAxisAlignment:
                                    MainAxisAlignment.center,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Category Title",
                                        style: TextStyle(
                                          fontSize: 13,
                                          color: Colors.black,
                                        ),
                                      ),
                                      Text(
                                        user.get("catTitle"),
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.black,
                                        ),
                                      ),

                                    ],
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: Container(

                                      child: Row(
                                        children: [
                                          Badge(
                                            toAnimate: false,
                                            shape: BadgeShape.square,
                                            badgeColor:
                                            Colors.indigoAccent,
                                            borderRadius:
                                            BorderRadius.circular(10),
                                            badgeContent: Text(
                                                user.get("catLan"),
                                                style: TextStyle(
                                                    color: Colors.white)),
                                          ),
                                          SizedBox(width: 3,),
                                          Badge(
                                            toAnimate: false,
                                            shape: BadgeShape.square,
                                            badgeColor:
                                            Colors.indigoAccent,
                                            borderRadius:
                                            BorderRadius.circular(10),
                                            badgeContent: Text(
                                                user.get("catTopic"),
                                                style: TextStyle(
                                                    color: Colors.white)),
                                          ),
                                          SizedBox(width: 3,),
                                          Badge(

                                            toAnimate: false,
                                            shape: BadgeShape.square,
                                            badgeColor:
                                            Colors.indigoAccent,
                                            borderRadius:
                                            BorderRadius.circular(10),
                                            badgeContent: Text(
                                                user.get("catCountry"),
                                                style: TextStyle(
                                                    color: Colors.white)),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 1,
                          color: Colors.grey[400],
                        ),
                        SizedBox(
                          height: 150,
                          child: Padding(
                              padding: EdgeInsets.only(top: 5),
                              child: CachedNetworkImage(
                                width: size.width,
                                height: size.height * 0.40,
                                imageUrl: user.get('postImage'),
                                placeholder: (context, url) =>
                                    Center(child: CircularProgressIndicator()),
                                errorWidget: (context, url, error) => Icon(
                                  Icons.error,
                                  color: Colors.red,
                                ),
                              )
                          ),
                        ),
                        Container(
                          height: 1,
                          color: Colors.grey[400],
                        ),
                        SizedBox(
                          height: 70,
                          child:Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment:
                              CrossAxisAlignment.center,
                              children: [
                                Text(
                                  "Category Description",
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.black,
                                  ),
                                ),
                                Text(
                                  user.get("catDesc"),
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.black,
                                  ),
                                ),


                              ],
                            ),
                          ),
                        ),
                        Divider(height: 2,color: Colors.black,),
                        Padding(
                          padding: const EdgeInsets.only(top:6.0,bottom: 2.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                            TextButton.icon(onPressed: (){}, icon:Icon(Icons.post_add),label:Text("Post a problem")),
                            TextButton.icon(onPressed: (){}, icon:Icon(Icons.question_answer),label: Text("Post a solution"))
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          }
          else if (snapshot.connectionState == ConnectionState.done && !snapshot.hasData) {
            // Handle no data
            return Center(
              child: Text("No Category found."),
            );
          } else {
            // Still loading
            return Center(child: CircularProgressIndicator());
          }
        }
    );




  }
}
