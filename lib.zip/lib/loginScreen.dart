import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutterthreadexample/views/admin/admin_dashboard.dart';
import 'package:flutterthreadexample/views/forget_pass.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'myHomePage.dart';
import 'registrationScreen.dart';

enum AuthFormType { anonymous }

class LoginScreen extends StatefulWidget {
  final AuthFormType authFormType;
  LoginScreen({Key key, this.authFormType}) : super(key: key);
  static const String idScreen="Login";

  @override
  State<LoginScreen> createState() => _LoginScreenState(authFormType: this.authFormType);
}

class _LoginScreenState extends State<LoginScreen> {
  AuthFormType authFormType;
  _LoginScreenState({this.authFormType});



  User user;


  var email = "";
  var password = "";
  final _auth = FirebaseAuth.instance;

  // Initially password is obscure
  bool _obscureText = true;
  final _formKey = GlobalKey<FormState>();
  TextEditingController emailTextEditingControler = TextEditingController();
  TextEditingController passwordTextEditingControler = TextEditingController();
  final dbRef = FirebaseDatabase.instance.reference().child("Users");
  userLogin() async {

    try {
      UserCredential user =await _auth.signInWithEmailAndPassword(email: email, password: password);
      if (user != null && await user.user.getIdToken() != null) {
        final User currentUser = _auth.currentUser;
        final userID = currentUser.uid;
        print(userID);
        if (currentUser.uid == user.user.uid) {
        await dbRef.child(userID).once().then((DataSnapshot snapshot) {
          setState(() {
            if(snapshot.value['admin']=='true'){
              adminLogin();
            }
            else if(snapshot.value['admin']=='false'){
              //userLg();
              checkEmailVerified(context);
            }
          });
        });
        }
      }

    }on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        print("No User Found for that Email");
        Fluttertoast.showToast(
            msg: "No user found for that email.",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.SNACKBAR,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
      } else if (e.code == 'wrong-password') {
        print("Wrong Password Provided by User");
        Fluttertoast.showToast(
            msg: "Wrong password provided for that user.",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.SNACKBAR,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
      }
    }
  }
  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    emailTextEditingControler.dispose();
    passwordTextEditingControler.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              children: [
                SizedBox(height: 15.0,),
                Image(
                  image: AssetImage("images/logo.png"),
                  width: 300.0,
                  height: 250.0,
                  alignment: Alignment.center,
                ),
                SizedBox(height: 1.0,),
                Text(
                  "Login as a User",
                  style: TextStyle(fontSize: 24.0,fontFamily: "Brand Bold"),
                  textAlign: TextAlign.center,
                ),
                Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      SizedBox(height: 1.0,),
                      TextFormField(
                        controller: emailTextEditingControler,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please Enter Email';
                          } else if (!value.contains('@')) {
                            return 'Please Enter Valid Email';
                          }
                          return null;
                        },
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          labelText: "Email",
                          labelStyle: TextStyle(
                            fontSize: 14.0,
                          ),
                          hintStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 10.0,
                          ),
                        ),
                        style: TextStyle(fontSize: 14.0),
                      ),
                      SizedBox(height: 1.0,),
                      TextFormField(
                        obscureText: _obscureText,
                        controller: passwordTextEditingControler,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please Enter Password';
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                          suffixIcon: IconButton(
                            icon: Icon(
                              // Based on passwordVisible state choose the icon
                              _obscureText
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                              color: Theme.of(context).primaryColorDark,
                            ),
                            onPressed: () {
                              // Update the state i.e. toogle the state of passwordVisible variable
                              setState(() {
                                _obscureText = !_obscureText;
                              });
                            },
                          ),
                          labelText: "Password",
                          labelStyle: TextStyle(
                            fontSize: 14.0,
                          ),
                          hintStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 10.0,
                          ),
                        ),
                        style: TextStyle(fontSize: 14.0),
                      ),
                      SizedBox(height: 10.0,),
                      ElevatedButton(
                          onPressed: (){
                            if (_formKey.currentState.validate()) {
                              setState(() {
                                email = emailTextEditingControler.text;
                                password = passwordTextEditingControler.text;
                              });
                              userLogin();
                            }
                          },
                          child: Container(
                            height: 50.0,
                            child: Center(
                              child: Text(
                                "Login",
                                style: TextStyle(
                                    fontSize: 18.0,
                                    fontFamily: "Brand Bold"
                                ),
                              ),
                            ),
                          )
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                builder: (context) => ForgotPassword(),
                                )
                            );
                          },
                          child: Text(
                            'Forgot Password ?',
                            style: TextStyle(fontSize: 13.0),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                TextButton(  onPressed: () {
                  Navigator.pushNamedAndRemoveUntil(context, RegistrationScreen.idScreen, (route) => false);
                },
                  child: Text(
                      "Do not have an Account? Register here"
                  ),
                ),
                Text("OR"),
                ElevatedButton(onPressed: ()
                async{
                  try{
                 if(AuthFormType.anonymous != null) {
                   await _auth.signInAnonymously();
                   Navigator.pushNamedAndRemoveUntil(context, MyHomePage.idScreen, (route) => false);
                 }
                    }
                    catch (e){
                      print(e);
                    }


                  //adminLogintest();
                }, child: Text("Login as a Guest")),
                ElevatedButton(onPressed: ()
                {adminLogintest();
                }, child: Text("Login as a Admin"))

              ],
            ),
          ),
        ),
      ),
    );
  }



  Future<void> checkEmailVerified(context) async{
    User _user = await _auth.currentUser;
    if(_user.emailVerified){
      SharedPreferences prefs=await SharedPreferences.getInstance();
      prefs.setString("email",emailTextEditingControler.text);
      displayToast("Login Successful", context);
      Navigator.push(context, MaterialPageRoute(builder: (context)=> MyHomePage()));
    }
    else{
      Fluttertoast.showToast(
          msg: "Please verify your email.",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.SNACKBAR,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.redAccent,
          textColor: Colors.white,
          fontSize: 16.0
      );
    }
  }

  void adminLogin() async{
    SharedPreferences prefs=await SharedPreferences.getInstance();
    prefs.setString("email",emailTextEditingControler.text);
    Navigator.push(context, MaterialPageRoute(builder: (context)=> Admin()));
  }
  void adminLogintest() async{
  //  SharedPreferences prefs=await SharedPreferences.getInstance();
  //  prefs.setString("email",emailTextEditingControler.text);
    Navigator.push(context, MaterialPageRoute(builder: (context)=> Admin()));
  }

  void userLg() async{
    SharedPreferences prefs=await SharedPreferences.getInstance();
    prefs.setString("email",emailTextEditingControler.text);
    Navigator.pushNamed(context, MyHomePage.idScreen);
  }
}

displayToast(String message,BuildContext context ){
  Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.SNACKBAR,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.green,
      textColor: Colors.white,
      fontSize: 16.0
  );
}

